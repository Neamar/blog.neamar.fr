; @package		jUpgradePRO 3.1.0 for Joomla 2.5 and 3.x - 2013-06-24
; @copyright	Copyright (©) 2006 - 2013 Matias Aguirre. All rights reserved.
; @license		GNU General Public License version 2 or later. See license.php in package.
; @author		Matias Aguirre http://www.matware.com.ar
; Published by redCOMPONENT.com 2013-06-24

This UNZIP_FIRST package contain the following elements:

1. The com_jUpgradePRO-3.1.0 component which is to be installed in a clean new joomla 2.5.x or joomla 3.0.x target site (No demodata).

2. The plg_jUpgradePRO-3.1.0 plugin which is to be installed in the source joomla 1.5.x site, when you choose to use the RESTful method.
(When using the Database method you do not need to install the plugin in the source site.)